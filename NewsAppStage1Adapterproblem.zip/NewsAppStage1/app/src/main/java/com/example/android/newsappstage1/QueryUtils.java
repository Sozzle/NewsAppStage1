package com.example.android.newsappstage1;

public class QueryUtils {


}
